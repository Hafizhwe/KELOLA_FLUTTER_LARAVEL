import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // Import the intl package

class Transaction {
  final String tanggal;
  final String keterangan;
  final int nominal;
  final String bank;

  Transaction({
    required this.tanggal,
    required this.keterangan,
    required this.nominal,
    required this.bank,
  });
}

class Dashboard extends StatefulWidget {
  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  // Sample transaction data (replace with your actual data source)
  final List<Transaction> transactionsincome = [
    Transaction(
        tanggal: '12/05/2023',
        keterangan: 'Makanan',
        nominal: 10000,
        bank: 'Mandiri'),
    Transaction(
        tanggal: '17/05/2023',
        keterangan: 'Belanja',
        nominal: 20000,
        bank: 'BNI'),
    Transaction(
        tanggal: '17/05/2023',
        keterangan: 'Belanja',
        nominal: 20000,
        bank: 'BNI'),
    Transaction(
        tanggal: '17/05/2023',
        keterangan: 'Belanja',
        nominal: 20000,
        bank: 'BNI'),
  ];
  final List<Transaction> transactionsexpense = [
    Transaction(
        tanggal: '15/05/2023',
        keterangan: 'Transfer',
        nominal: -5000,
        bank: 'BCA'),
    Transaction(
        tanggal: '15/05/2023',
        keterangan: 'Transfer',
        nominal: -5000,
        bank: 'BCA'),
    Transaction(
        tanggal: '15/05/2023',
        keterangan: 'Transfer',
        nominal: -5000,
        bank: 'BCA'),
  ];

  final List<Transaction> transactionsbill = [
    Transaction(
        tanggal: '15/05/2023',
        keterangan: 'Paylater',
        nominal: -800000,
        bank: 'Shopee'),
  ];

  int calculateTotal(List<Transaction> transactions, bool isIncome) {
    return transactions
        .where((transaction) =>
            isIncome ? transaction.nominal > 0 : transaction.nominal < 0)
        .fold(0, (total, transaction) => total + transaction.nominal);
  }

  @override
  Widget build(BuildContext context) {
    // Get the current date
    String currentDate = DateFormat('dd MMMM yyyy').format(DateTime.now());

    return Scaffold(
      body: Stack(
        children: [
          // Background image
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(
                      'images/Background 2.png'), // Path to your background image
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),

          Center(
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  // Container 1: Header with current date
                  Container(
                    padding: EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          currentDate, // Display the current date
                          style: TextStyle(fontSize: 16.0, color: Colors.black),
                        ),
                      ],
                    ),
                  ),

                  // Container 2: Income with DecoratedBox
                  Container(
                    width: 335,
                    padding: EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: Colors.grey[300]!),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          'Income',
                          style: TextStyle(
                            fontSize: 16.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 8.0),

                        // Improved transaction list with divider and error handling
                        ListView.separated(
                          shrinkWrap: true, // Prevent excessive scrolling
                          physics:
                              NeverScrollableScrollPhysics(), // Disable scrolling if needed
                          itemCount: transactionsincome.length,
                          itemBuilder: (context, index) {
                            final transaction = transactionsincome[index];
                            return TransaksiItem(
                              tanggal: transaction.tanggal,
                              keterangan: transaction.keterangan,
                              nominal: transaction.nominal,
                              bank: transaction.bank,
                            );
                          },
                          separatorBuilder: (context, index) => Divider(
                            height: 1,
                            color: Colors.grey[
                                300], // Add a subtle divider between transactions
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 10),

                  // Container 3: Expense with DecoratedBox
                  Container(
                    width: 335,
                    padding: EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: Colors.grey[300]!),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          'Expenses',
                          style: TextStyle(
                            fontSize: 16.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 8.0),

                        // Improved transaction list with divider and error handling
                        ListView.separated(
                          shrinkWrap: true, // Prevent excessive scrolling
                          physics:
                              NeverScrollableScrollPhysics(), // Disable scrolling if needed
                          itemCount: transactionsexpense.length,
                          itemBuilder: (context, index) {
                            final transaction = transactionsexpense[index];
                            return TransaksiItem(
                              tanggal: transaction.tanggal,
                              keterangan: transaction.keterangan,
                              nominal: transaction.nominal,
                              bank: transaction.bank,
                            );
                          },
                          separatorBuilder: (context, index) => Divider(
                            height: 1,
                            color: Colors.grey[
                                300], // Add a subtle divider between transactions
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 10),

                  // Container 4: Bills with DecoratedBox
                  Container(
                    width: 335,
                    padding: EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: Colors.grey[300]!),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          'Bills',
                          style: TextStyle(
                            fontSize: 16.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 8.0),

                        // Improved transaction list with divider and error handling
                        ListView.separated(
                          shrinkWrap: true, // Prevent excessive scrolling
                          physics:
                              NeverScrollableScrollPhysics(), // Disable scrolling if needed
                          itemCount: transactionsbill.length,
                          itemBuilder: (context, index) {
                            final transaction = transactionsbill[index];
                            return TransaksiItem(
                              tanggal: transaction.tanggal,
                              keterangan: transaction.keterangan,
                              nominal: transaction.nominal,
                              bank: transaction.bank,
                            );
                          },
                          separatorBuilder: (context, index) => Divider(
                            height: 1,
                            color: Colors.grey[
                                300], // Add a subtle divider between transactions
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 15),
                ],
              ),
            ),
          ),
          // Position the FAB outside the scrollable area:
          Positioned(
            bottom: 20,
            right: 20,
            child: FloatingActionButton(
              onPressed: () {
                Navigator.pushNamed(context, '/input');
                print('Add transaction button pressed');
              },
              child: Icon(
                Icons.add,
                color: Colors.white,
                size: 32,
              ),
              backgroundColor: const Color.fromRGBO(140, 226, 218, 0.8),
              shape: RoundedRectangleBorder(
                borderRadius:
                    BorderRadius.circular(30.0), // Adjust the radius as needed
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Widget for displaying individual transactions
class TransaksiItem extends StatelessWidget {
  final String tanggal;
  final String keterangan;
  final int nominal;
  final String bank;

  TransaksiItem({
    required this.tanggal,
    required this.keterangan,
    required this.nominal,
    required this.bank,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(keterangan),
      subtitle: Text('$tanggal - $bank'),
      trailing: Text(
        'Rp $nominal',
        style: TextStyle(
          color: nominal < 0 ? Colors.red : Colors.green,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}
