import 'dart:convert';
import 'package:dio/dio.dart';

class AuthService {
  final Dio _dio = Dio();
  final String baseUrl = 'http://192.168.1.28/api';

  Future<Map<String, dynamic>> login(String username, String password) async {
    try {
      Response response = await _dio.post('$baseUrl/login', data: {
        'username': username,
        'password': password,
      });

      return json.decode(response.data);
    } catch (error) {
      throw (error.toString());
    }
  }

  Future<Map<String, dynamic>> register(
      String fullname, String email, String username, String password) async {
    try {
      Response response = await _dio.post('$baseUrl/register', data: {
        'fullname': fullname,
        'email': email,
        'username': username,
        'password': password,
      });

      return json.decode(response.data);
    } catch (error) {
      throw (error.toString());
    }
  }

  Future<void> logout(String token) async {
    try {
      Response response = await _dio.post('$baseUrl/logout',
          options: Options(headers: {'Authorization': 'Bearer $token'}));

      if (response.statusCode == 200) {
        return;
      } else {
        throw ('Failed to logout');
      }
    } catch (error) {
      throw (error.toString());
    }
  }
}
