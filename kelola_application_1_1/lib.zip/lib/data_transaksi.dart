import 'package:flutter/material.dart';

class Transaksi extends StatefulWidget {
  const Transaksi({Key? key}) : super(key: key);

  @override
  _TransaksiState createState() => _TransaksiState();
}

class _TransaksiState extends State<Transaksi> {
  String selectedMonth = 'January';
  String selectedYear = DateTime.now().year.toString();
  List<String> years =
      List.generate(10, (index) => (DateTime.now().year - index).toString());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('images/Background 2.png'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(16.0),
                  child: ListView(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    children: [
                      const SizedBox(height: 1.0),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          DropdownButton<String>(
                            value: selectedMonth,
                            items: <String>[
                              'January',
                              'February',
                              'March',
                              'April',
                              'May',
                              'June',
                              'July',
                              'August',
                              'September',
                              'October',
                              'November',
                              'December'
                            ].map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(
                                  value,
                                  style: const TextStyle(color: Colors.black),
                                ),
                              );
                            }).toList(),
                            onChanged: (String? newValue) {
                              setState(() {
                                selectedMonth = newValue!;
                              });
                            },
                          ),
                          DropdownButton<String>(
                            value: selectedYear,
                            items: years
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(
                                  value,
                                  style: const TextStyle(color: Colors.black),
                                ),
                              );
                            }).toList(),
                            onChanged: (String? newValue) {
                              setState(() {
                                selectedYear = newValue!;
                              });
                            },
                          ),
                          ElevatedButton(
                            onPressed: () {
                              // Navigasi ke halaman transaksi
                              Navigator.pushNamed(context, '/transactions');
                            },
                            style: ButtonStyle(
                              backgroundColor: MaterialStateProperty.all<Color>(
                                  Color.fromRGBO(140, 226, 218, 0.8)),
                              foregroundColor: MaterialStateProperty.all<Color>(
                                  Colors.white),
                            ),
                            child: const Text('Lihat Transaksi'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                // Bagian daftar transaksi dan ringkasan transaksi
                Container(
                  padding: const EdgeInsets.all(16.0),
                  margin: const EdgeInsets.symmetric(horizontal: 10.0),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text(
                        'Daftar Transaksi',
                        style: TextStyle(
                          fontSize: 18.0,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 16.0),
                      // Contoh daftar transaksi
                      Column(
                        children: [
                          ListTile(
                            leading: const Icon(Icons.arrow_downward,
                                color: Colors.green),
                            title: const Text('Income 1'),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: const [
                                Text('Rp 1.000.000'),
                                Text('Bank: BCA'),
                                Text('Note: Salary'),
                              ],
                            ),
                            trailing: const Text('01-01-2024'),
                          ),
                          ListTile(
                            leading: const Icon(Icons.arrow_upward,
                                color: Colors.red),
                            title: const Text('Expense 1'),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: const [
                                Text('Rp 500.000'),
                                Text('Bank: BNI'),
                                Text('Note: Groceries'),
                              ],
                            ),
                            trailing: const Text('02-01-2024'),
                          ),
                          ListTile(
                            leading: const Icon(Icons.arrow_upward,
                                color: Colors.red),
                            title: const Text('Bill 1'),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: const [
                                Text('Rp 200.000'),
                                Text('Bank: Mandiri'),
                                Text('Note: Internet bill'),
                              ],
                            ),
                            trailing: const Text('03-01-2024'),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16.0),
                      const Text(
                        'Ringkasan Transaksi',
                        style: TextStyle(
                          fontSize: 18.0,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 16.0),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: const [
                          Text('Total Income'),
                          Text('Rp 1.000.000',
                              style: TextStyle(color: Colors.green)),
                        ],
                      ),
                      const SizedBox(height: 8.0),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: const [
                          Text('Total Expense'),
                          Text('Rp 500.000',
                              style: TextStyle(color: Colors.red)),
                        ],
                      ),
                      const SizedBox(height: 8.0),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: const [
                          Text('Total Tagihan'),
                          Text('Rp 200.000',
                              style: TextStyle(color: Colors.red)),
                        ],
                      ),
                      const SizedBox(height: 8.0),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: const [
                          Text('Sisa Budget'),
                          Text('Rp 300.000'),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 15),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: Container(
        width: double.infinity,
        color: Colors.transparent,
        padding: const EdgeInsets.all(16.0),
        child: ElevatedButton(
          onPressed: () {
            // Tambahkan fungsi untuk export Excel di sini
          },
          style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all<Color>(
                Color.fromRGBO(140, 226, 218, 0.8)),
            foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
          ),
          child: const Text('Export Excel'),
        ),
      ),
    );
  }
}

void main() {
  runApp(const MaterialApp(
    home: Transaksi(),
  ));
}
